import Vue from 'vue'
import VideoPlayer from '../../../index'


Vue.use(VideoPlayer, /* {
  options: global default videojs options,
  events: global videojs videojs events
} */)
