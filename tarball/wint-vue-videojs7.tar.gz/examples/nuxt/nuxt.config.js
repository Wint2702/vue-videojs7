export default {
    plugins: [
        {src: '~/plugins/vue-videojs7.js', mode: 'client'}
    ]
}