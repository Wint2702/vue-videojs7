module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/vue-videojs7/' : '/',
  outputDir: 'docs'
}
